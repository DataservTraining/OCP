import java.util.ArrayList;

class Whiz{ 
    public static void main(String args[]) throws Exception{ 
    	short s = 10;
    	ArrayList<String> list = new ArrayList<String>();
    	
//    System.out.print(new Whiz().check(10)); 
    } 
    boolean check(short x){ 
    if(x<10) return true; 
    else return false; 
    } 
    } 