
public interface MyInterface {

}
