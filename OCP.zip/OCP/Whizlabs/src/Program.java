import java.io.IOException;

class A{
	void test() throws IOException {
		
	}
}

class B extends A{
	void test() throws IOException, NullPointerException {
		
	}
	
	void myMeth() {
		
	}
}

class C extends A{
	
}


public class Program {

	public static void main(String[] args) {
		A a = new A();
		B b = new B();
		C c = new C();
		
		b = (B)(A) c;
		b = (B)a;
		b.myMeth();
		
		try {
			a.test();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
