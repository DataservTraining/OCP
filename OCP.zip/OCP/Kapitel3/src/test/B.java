package test;

public class B {
	
	public void m(int y) {
		testMethod(y);
	}
	
	private void testMethod(int x) {
		assert x > 0 : x;
		System.out.println("B: " + x);
	}

}
