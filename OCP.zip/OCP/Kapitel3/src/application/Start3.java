package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.Reader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


//interface AutoCloseable{  // seit Java 1.7
//	public abstract void close() throws Exception;
//}
//
//interface Closeable extends AutoCloseable{     // seit java 1.5
//	public abstract void close() throws IOException;
//}


public class Start3 {

	public static void main(String[] args) throws FileNotFoundException, IOException {
//		File file = new File("");
//			try (Reader reader = new BufferedReader(new FileReader(file))) {
//
//			// do stuff
//
//			}
		
		try (FileWriter out = new FileWriter("text.txt");
//			 Connection con = DriverManager.getConnection("");
//			 Statement stmt = con.createStatement(ResultSet.CONCUR_UPDATABLE, ResultSet.TYPE_SCROLL_INSENSITIVE);
			InputStream reader = System.in;
			PrintStream outstream =	System.out;){
			
			System.out.println("try");
			
			out.write("Hallo");
			
			// Anweisungen
			
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
//		finally {
//			
//		}
		
		System.out.println("Ende");

	}

}
