package application;

import test.B;

public class Start {

	public static void main(String[] args) {
		A a = new A();
		B b = new B();
		Start s = new Start();
		
		a.m(-1);
		b.m(-2);
		s.m(-3);
		
		//test(-56);

	}
	
	private static void test(int i) {
		// -ea / enableassertions
		// -da / disableassertions
		// -esa / enablesystemassertions
		// -dsa / disablesystemassertions
		
		// -ea -da:com.foo 
		assert i >= 0 : "Falscher Wert für i: " + i;
		System.out.println(i);
		
		
	}
	
	public void m(int y) {
		testMethod(y);
	}
	
	private void testMethod(int x) {
		assert x > 0 : x;
		System.out.println("Start: " + x);
	}

}
