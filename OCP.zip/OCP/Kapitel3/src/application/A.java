package application;

public class A {
	public void m(int y) {
		testMethod(y);
	}
	
	private void testMethod(int x) {
		assert x > 0 : x;
		System.out.println("A: " + x);
	}
}
