package application;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

public class Start2 {

	public static void main(String[] args) throws Exception {
		int x = 10;
		try {
			if(x < 10) {
				throw new SQLException("SQL");
			} else if(x == 0){
				throw new IOException("IO");
			} else {
				throw new ClassNotFoundException();
			}
		} catch(ReflectiveOperationException e) {
			System.out.println(e.getMessage());
			e = new ClassNotFoundException();
			throw e;
		} catch(SQLException | IOException e) {
			System.out.println(e.getMessage());
//			e = new IOException();
			throw e;
		} 

	}

}
