package application;

import java.io.IOException;
import java.sql.SQLException;

class Bad implements AutoCloseable {

	String name;

	Bad(String n) {
		name = n;
	}

	public void close() throws IOException {

		throw new IOException("Closing - " + name);

	}
}

public class Suppressed {

	public static void main(String[] args) {

		try (Bad b1 = new Bad("1"); Bad b2 = new Bad("2")) {

// do stuff
			throw new SQLException("SQL");

		} catch (Exception e) {

			System.err.println(e.getMessage());

			for (Throwable t : e.getSuppressed()) {

				System.err.println("suppressed:" + t);

			}
		}
	}
}

//public class Suppressed {
//
//	public static void main(String[] args) {
//
//		try (One one = new One()) {
//
//			throw new Exception("Try");
//
//		} catch (Exception e) {
//
//			System.err.println(e.getMessage());
//
//			for (Throwable t : e.getSuppressed()) {
//
//				System.err.println("suppressed:" + t);
//
//			}
//		}
//	}
//}

class One implements AutoCloseable {

	public void close() throws IOException {

		throw new IOException("Closing");

	}
}