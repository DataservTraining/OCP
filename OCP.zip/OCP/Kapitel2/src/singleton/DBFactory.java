package singleton;

public class DBFactory {
	private static DBFactory factory = new DBFactory();
	private DBFactory() {
		
	}
	
	public static DBFactory getInstance() {
		return factory;
	}
}
