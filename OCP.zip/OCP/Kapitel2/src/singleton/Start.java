package singleton;

import java.util.ArrayList;
import java.util.List;
import java.util.*;
import java.sql.*;

public class Start {
	int x = 9;

	public static void main(String[] args) throws Exception {
//		final int i = 0;
//		final int j;
//		j = 2;
//
//		int x = (int) (Math.random() * 3);
//
//		switch (x) {
//		case i: {
//			System.out.print("A");
//		}
//		case 1:
//			System.out.print("B");
//			break;
//		case j:
//			System.out.print("C");
//		}
//		
//		int note;
//		Scanner scanner = new Scanner(System.in);
//		note = scanner.nextInt();
//		
//		switch (note) {
//		case 5:
//		case 6:
//			System.out.print("nicht ");
//		case 1:
//		case 2:
//		case 3:
//		case 4:
//			System.out.println("bestanden");
//		}
	}

}