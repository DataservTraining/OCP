package application;



public class Lebewesen {
	protected int alter = 10;
	
	

	public Lebewesen(int alter) {
		super();
		this.alter = alter;
	}

	public Lebewesen() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getAlter() {
		return alter;
	}

	public void setAlter(int alter) {
		this.alter = alter;
	}

	@Override
	public String toString() {
		return "Lebewesen [alter=" + alter + "]";
	}
	
	
}
