package application;


public class VerkettungTest {

	public static void main(String[] args) {
		A a = new B(45, "Welt");
	}

}

/*
1. Versuch

"static {System.out.println(sB);} " + sB
"Konstruktor A(int a, String textA): " + a + " " + textA)
"Konstruktor B(int b, String textB): " + b + " " + textB




2. Versuch

"static {System.out.println(sA);} " + sA                 //1
"static {System.out.println(sB);} " + sB)                //3
System.out.println(textA);                               // Class A
"Konstruktor A(int a, String textA): " + a + " " + textA // 35 , t
{ System.out.println(textA);}                            //t
"Konstruktor B(int b, String textB): " + b + " " + textB // 45, Welt

*/