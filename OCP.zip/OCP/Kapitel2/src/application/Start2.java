package application;

//abstract class Basis extends Object{
//	int z = 0;
//
//	
//	
//	public Basis() throws IllegalArgumentException{
//		super();
//		if(z == 0) throw new IllegalArgumentException();
//		this.z = 100;
//	}
//
//
//
//	public Basis(int z) {
//		super();
//		this.z = z;
//	}
//	
//	public abstract void mytest();
//}
//
//
//class A extends Basis{
//	
//	int x = 10;
//
//	
//	
//	public A() {
////		this(4);
//
//	}
//
//
//
//	public A(int w) {
//		
//		super();
//		this.x = w;
//	}
//
//
//
//	@Override
//	public void mytest() {
//		// TODO Auto-generated method stub
//		
//	}
//
//	
//}
//
//class B extends A{
//	int x = 20;
//	int y = 100;
//	
//	
//
//}
//
//class C extends B{
//	int x = 20;
//	int y = 100;
//	
//	
//}
//
//
//
public class Start2 {
//
	public static void main(String[] args) throws Throwable{
//		A a = null;
//		try {
//			a = new A();
//		} catch(IllegalArgumentException e) {
//			e.printStackTrace();
//		}
//		System.out.println(a);
//		B b = new B();
//		C c = new C();
//		a = b;
//		b = (B) a;
////		b = (B) c;
//		a = c;
//		a = b;
//		
//		System.out.println("x: " + a.x);
//		System.out.println("x: " + b.x);
////		System.out.println("x: " + b.y);
////		System.out.println("x: " + b.test());
//
//		
//		
	}

}
