package application;

public class Adresse {
	private String ort;

	
	
	public Adresse(String ort) {
		super();
		this.ort = ort;
	}

	public Adresse() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	@Override
	public String toString() {
		return "Adresse [ort=" + ort + "]";
	}
	
	
	
}
