package application;

import java.util.Objects;

public class Person extends Lebewesen  implements Cloneable{
	private final String name = "";
	private Adresse adresse;
	//private Person partner;
	public Person() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Person(int alter) {
		super(alter);
		// TODO Auto-generated constructor stub
	}
	public Person(int alter, String name, Adresse adresse) {
		super(alter);
//		this.name = name;
		this.adresse = adresse;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
//		this.name = name;
	}
	public Adresse getAdresse() {
		return adresse;
	}
	public void setAdresse(Adresse adresse) {
		this.adresse = adresse;
	}
	
	@Override
	public String toString() {
		return "Person [name=" + name + ", adresse=" + adresse + ", alter=" + alter + "]";
	}
	@Override
	public Person clone() {
		return new Person(getAlter(), this.name, new Adresse(adresse.getOrt()));
	}
	@Override
	public int hashCode() {
		return Objects.hash(adresse, name);
	}
	
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Person other = (Person) obj;
		return Objects.equals(adresse, other.adresse) && Objects.equals(name, other.name);
	}
	
	
	
}
