package application;


import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

public class Start {

	public static void main(String[] args) {
		Person pers = null;
		
		Person person1 = new Person(35, "Willi", new Adresse("München"));
		Person person2 = new Person(30, "Egon", new Adresse("München"));
		Person person1Clone = null;
		
			Object obj = person1.clone();
			if(obj.getClass() == Person.class) person1Clone = (Person) obj;
			
			Class personClass = Person.class;
			
			Field[] felder = personClass.getDeclaredFields();
			
			for(Field feld : felder) {
				int modifier = feld.getModifiers();
				System.out.println(modifier);
				System.out.println((modifier & Modifier.PUBLIC)!= 0 ? "public" : "!public");
				System.out.println((modifier & Modifier.FINAL)!= 0 ? "final" : "");
				System.out.println((modifier & Modifier.PRIVATE)!= 0 ? "private" : "");
				System.out.println(feld.getName());
				
			}
		
		
		System.out.println(person1);
		System.out.println(person1Clone);
		
		person1.getAdresse().setOrt("Köln");
		
		System.out.println(person1);
		System.out.println(person1Clone);

	}

}
