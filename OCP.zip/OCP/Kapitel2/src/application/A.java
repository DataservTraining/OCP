package application;

class A{
	static int sA = 1;
	int a = 10;
	String textA = "Class A";
	public A() {
		super();
	}
	public A(int a) {
		this(a, "Hallo");
		this.a = a;
		System.out.println("Konstruktor A(int a): " + a);
	}
	{ System.out.println(textA);}
	public A(int a, String textA) {
		super();
		this.a = a;
		this.textA = textA;	
		System.out.println("Konstruktor A(int a, String textA): " + a + " " + textA);
	}
	static {System.out.println("static {System.out.println(sA);} " + sA);}
	static {sA = 2;}
}

class B extends A{
	static int sB = 2;
	int b = 10;
	String textB = "Class B";
	public B() {
		this(0, "Test");
	}
	public B(int b) {
		this();
		this.b = b;
		System.out.println("Konstruktor B(int b): " + b);
	}
	{ System.out.println(textA);}
	public B(int b, String textB) {
		super(b - 10, textB.substring(3));
		this.b = b;
		this.textB = textB;	
		System.out.println("Konstruktor B(int b, String textB): " + b + " " + textB);
	}
	static {sB = 3;}
	static {System.out.println("static {System.out.println(sB);} " + sB);}
}
