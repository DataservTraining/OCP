package application;

public interface Move { 
    public static void main(String [ ] args) { 
    	System.out.println("Move"); 
    } 
    public static void print(){ } 
    }
