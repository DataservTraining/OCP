package application;

public interface MyInterface2 {
	public default int add(int a, int b) {
		//t();
		return a + b;
	}
}
