package application;

public interface MyInterface {
	/* public static final */ int x = 56;
	/* public abstract */ void test();
	
	public default int add(int a, int b) {
		//t();
		return a + b;
	}

	/* Version 9
	private void t() {
		
	}
	
	private static void st() {
		
	}
	*/
	
	public static int firststatic() {
		
		return 0;
	}
	
}
