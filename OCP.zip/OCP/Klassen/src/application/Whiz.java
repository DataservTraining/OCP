package application;

public class Whiz {

	static int x = 2;

	public static void main(String args[]) {
		if (x > 1) {
			x++;
			int x = 4;
		}
		System.out.println(x);
		final int x = 10;
	}
}