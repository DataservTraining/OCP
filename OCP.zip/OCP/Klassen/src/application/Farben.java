package application;

public enum Farben {
	ROT("Rot", 0xFF0000), GELB("Gelb", 0xFF00FF), GRUEN("Grün", 0xFFFF00);
	
	private String bezeichner;
	private int farbwert;
	
//	private Farben() {
//		
//	}
	Farben(String farbe, int farbwert) {
		this.bezeichner = farbe;
		this.farbwert = farbwert;
	}

	public String getBezeichner() {
		return bezeichner;
	}

	public int getFarbwert() {
		return farbwert;
	}
	
	
	
}
