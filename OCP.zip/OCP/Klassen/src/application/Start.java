package application;

abstract class Test{
	public void test() {}
}

public class Start {

	public static void main(String[] args) {
//		Test t = new Test();
	}

	
	public static void aMethode(Integer x, Integer y  ) {
		System.out.println(x + y);
	}
	public static void aMethode(int x, int y  ) {
		System.out.println(x + y);
	}
	
	public static void aMethode(int... x) {
		int summe = 0;
		for(int i : x)
			summe += i;
		System.out.println(summe);
	}
	
	
//	public static void aMethode(int x, String[] d  ) {
//		for(int index= 0; index < d.length; ++index) {
//			System.out.println(d[index]);
//		}
//	}
	public static void aMethode(int x, String d  ) {
		
			System.out.println(d);
		
	}
	
	
}
