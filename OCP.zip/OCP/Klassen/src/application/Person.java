package application;

import entities.Lebewesen;

public class Person extends Lebewesen{
	private transient String name;
	Object o;
	
	public void test(final int x, final Person p) {
		//x = 100;
		p.name = "";
		System.out.println(alter);
//		Lebewesen l = new Lebewesen();
//		System.out.println(l.alter);
		Person pers = new Person();
		System.out.println(pers.alter);
	}
}
