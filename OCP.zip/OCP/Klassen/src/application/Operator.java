package application;

public enum Operator {
	PLUS{
		@Override
		public double operate(double w1, double w2) {
			// TODO Auto-generated method stub
			return w1 + w2;
		}},
	MINUS {
		@Override
		public double operate(double w1, double w2) {
			// TODO Auto-generated method stub
			return w1 - w2;
		}
	},
	MAL {
		@Override
		public double operate(double w1, double w2) {
			// TODO Auto-generated method stub
			return w1 * w2;
		}
	},
	DIV {
		@Override
		public double operate(double w1, double w2) {
			if(w2 == 0) {
				throw new IllegalArgumentException("Divisor gleich 0");
			}
			return w1 / w2;
		}
	};
	
	public abstract double operate(double w1, double w2);
}
