package entities;

import application.MyInterface;
import application.MyInterface2;

public class Lebewesen implements MyInterface, MyInterface2{
	protected int alter = 10;

	@Override
	public void test() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int add(int a, int b) {
		// TODO Auto-generated method stub
		//return MyInterface.super.add(a, b);
		return a+b;
	}
	
	
	
	
}
