package application;

import java.time.Duration;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Whizlab {
	public static void main(String[] args) {
		Duration due = Duration.ofDays(-3);
		LocalDate ld = LocalDate.of(2016, 1, 1);
		ld = ld.plus(1, ChronoUnit.HOURS);
		System.out.println(ld.plus(due.toDays(), ChronoUnit.DAYS));
	}
}