package application;

import java.util.Locale;
import java.util.ResourceBundle;

public class ResourceBundleTest {

	public static void main(String[] args) {
		Locale.setDefault(new Locale("de", "DE"));
		ResourceBundle rb = ResourceBundle.getBundle("Bundle", new Locale("fr", "FR"));
		System.out.println(rb.getString("text"));
		System.out.println(rb.getString("text2"));
		System.out.println(rb.getString("text3"));

	}

}
