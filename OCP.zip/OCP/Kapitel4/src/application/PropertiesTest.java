package application;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

public class PropertiesTest {

	public static void main(String[] args) {
		Properties props = new Properties();
		try(FileReader in = new FileReader("config.props");
			FileWriter out = new FileWriter("config.props", true)){
			props.load(in);
			props.list(System.out);
			
			props.put("key4", "value4");
			props.setProperty("key10", "value10");
			props.store(out, "Konfiguration");
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
